#!/bin/bash
rm -rf "$1" &> /dev/null
